cc-shapefiles
=============

NOTE(mateo): Greetings, from the future (the past to you, dear reader).

In 2018, I began publishing this jar from our internal repo. This just brought in the 
Scala, the shapefile resourceds are hosted internally and fetched by Pants at build time.

The resources files themselves are still hosted in the internal Git repo, cc-shapefiles.
